<?php

//define('BDD_hote','vpsloic.loicbertrand.net');
//define('BDD_port','3310');
//define('BDD_base_de_donnees','programmation_web_tp2');
//define('BDD_usager','iut');
//define('BDD_mot_de_passe','password');

define('DB_HOST','127.0.0.1');
define('DB_PORT','3306');
define('DB_DATABASE','bejeweled');
define('DB_USER','root');
define('DB_PASSWORD','');