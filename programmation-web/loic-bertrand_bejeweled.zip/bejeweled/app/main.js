(function () {
    initialize_game();
})();