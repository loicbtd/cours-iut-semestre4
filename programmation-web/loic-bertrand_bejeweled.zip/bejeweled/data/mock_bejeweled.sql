LOAD DATA LOCAL INFILE './mockdata/leaderboard.csv' INTO TABLE leaderboard FIELDS TERMINATED BY ';' (username,score);
